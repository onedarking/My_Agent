﻿import streamlit as st
import requests
import pandas as pd

st.title("📊 Office Agent 平台")

tab1, tab2, tab3 = st.tabs(["仪表盘", "文档处理", "分析"])

with tab1:
    st.metric("今日任务", 5)
    st.metric("成功率", "100%")

with tab2:
    if st.button("执行文档处理"):
        st.write("🚀 执行中...")
        res = requests.post("http://127.0.0.1:8000/api/process")
        st.success("完成")
        st.write(res.json())

with tab3:
    try:
        df = pd.read_excel("data/output.xlsx")
        st.dataframe(df)
    except:
        st.warning("暂无数据")
